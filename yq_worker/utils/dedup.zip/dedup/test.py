# -*- coding: utf-8 -*-
'''
Created on 2018/12/17 4:05 PM
---------
@summary:
---------
@author: liubo
'''

from spider.dedup import Dedup

def test_bloomfilter():
    dedup = Dedup()

    # 批量去重
    datas = [1,2,-32,2]
    is_added = dedup.add(datas, True)

    print(datas, is_added)
    is_exists = dedup.get(datas)

    print(datas, is_exists)


def test_expirefilter():
    dedup = Dedup(Dedup.ExpireFilter, expire_time=3)

    # 批量去重
    datas = [1,2,-32,2, 4, 5]
    datas_fingerprints = [1, 2, -32, 2, 4, 5]
    is_added = dedup.add(datas[:-3], True)
    #
    # print(datas, is_added)
    # is_exists = dedup.get(datas)
    #
    # print(datas, is_exists)
    
    dedup.filter_exist_data(datas=datas, callback=lambda x: print(x, '已存在'))
    print(datas, datas_fingerprints)



if __name__ == '__main__':
    test_expirefilter()